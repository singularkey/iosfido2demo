//
//  SingularKey.h
//  SingularKey
//
//  Created by neetin on 2/28/19.
//  Copyright © 2019 SingularKey. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SingularKey.
FOUNDATION_EXPORT double SingularKeyVersionNumber;

//! Project version string for SingularKey.
FOUNDATION_EXPORT const unsigned char SingularKeyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SingularKey/PublicHeader.h>


